class Todo {
  int? id;
  String task;
  bool isComplete;

  Todo(this.id, this.task, this.isComplete);
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'task': task,
      'isComplete': isComplete,
    };
  }

  factory Todo.fromMap(Map<String, dynamic> map) {
    return Todo(
      map['id'],
      map['task'],
      map['isComplete'],
    );
  }
}
