import 'package:flutter/material.dart';
import 'drawer.dart';

class TodolistPage extends StatefulWidget {
  const TodolistPage({super.key});

  @override
  State<TodolistPage> createState() => _TodolistPageState();
}

class _TodolistPageState extends State<TodolistPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Todolist'),
      ),
      drawer: CustomDrawer(),
      body: ListView(
        children: [
          ListTile(
            title: Text('ไปรับแฟนกินข้าว'),
            trailing: Checkbox(value: true, onChanged: (value) {}),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        child: const Icon(Icons.add),
      ),
    );
  }
}
