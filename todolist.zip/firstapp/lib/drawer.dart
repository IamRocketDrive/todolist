import 'package:firstapp/todolist.dart';
import 'package:flutter/material.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    //throw UnimplementedError();
    return Drawer(
      child: ListView(
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(color: Colors.cyan),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundImage: NetworkImage(
                      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWLZEsfViVN8geWZAoruA5nVopbk7Tdl8pBQ&s'),
                ),
                SizedBox(height: 8),
                const Text(
                  'Panukorn Puripanyanan',
                  style: TextStyle(color: Colors.white, fontSize: 24),
                ),
              ],
            ),
          ),
          ListTile(
            title: const Text('Profile page'),
            onTap: () {},
          ),
          ListTile(
            title: const Text('TodoLists'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => TodolistPage()),
              );
            },
          )
        ],
      ),
    );
  }
}
